<?php
require "koneksi.php"; // Pastikan ini adalah file yang mengatur koneksi ke database
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $tanggal = $_POST["tanggal"];
  $keterangan = $_POST["keterangan"];
  $sumber = $_POST["sumber"];
  $jumlah = $_POST["jumlah"];

  // Tambahkan kode SQL untuk menyimpan data ke database SIKeuangan
  // Gantilah 'nama_tabel' dengan nama tabel yang sesuai
  $sql = "INSERT INTO pemasukkan (tanggal, keterangan, sumber, jumlah) VALUES ('$tanggal', '$keterangan', '$sumber', '$jumlah')";
  $result = mysqli_query($koneksi, $sql);

  if ($result) {
    $response = array("success" => true);
  } else {
    $response = array("success" => false);
  }

  echo json_encode($response);
}
?>
