<?php
require 'koneksi.php';

if (empty($_POST['tanggal']) || empty($_POST['keperluan']) || empty($_POST['sumber']) || empty($_POST['jumlah']) || empty($_POST['id'])) {
	echo '{"status" : "Error", "Message" : "tanggal, keperluan, sumber, jumlah, and ID is required!"}';
	exit();
}

if (isset($_POST['id'])) {
	$tanggal = $_POST['tanggal'];
	$keperluan = $_POST['keperluan'];
	$sumber = $_POST['sumber'];
	$jumlah = $_POST['jumlah'];
	$id = $_POST['id'];

	//  query update data 
	$result  = mysqli_query($koneksi, "UPDATE pengeluaran SET tanggal='$tanggal' , keperluan='$keperluan' , sumber = '$sumber', jumlah='$jumlah' WHERE id='$id'");
	// echo $result; die;
	if ($result) {
		echo '{"Status" : "Succes", "Message" : "Data berhasil diupdate!"}';
	} else {
		echo '{"Status" : "Error", "Message" : ' . mysqli_error($koneksi) . '}';
	}
}
