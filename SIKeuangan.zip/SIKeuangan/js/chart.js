<script>
    // Data pemasukkan dan pengeluaran (misalnya, data ini diambil dari PHP)
    var pemasukkanData = <?= $hasilHargaPemasukkan ?>;
    var pengeluaranData = <?= $hasilHargaPengeluaran ?>;

    var ctx = document.getElementById('totalRevenueChart').getContext('2d');

    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Pemasukkan', 'Pengeluaran'],
            datasets: [
                {
                    label: 'Pemasukkan',
                    data: [pemasukkanData],
                    borderColor: 'green',
                    backgroundColor: 'rgba(0, 128, 0, 0.2)'
                },
                {
                    label: 'Pengeluaran',
                    data: [pengeluaranData],
                    borderColor: 'red',
                    backgroundColor: 'rgba(255, 0, 0, 0.2)'
                }
            ]
        },
        options: {
            scales: {
                x: {
                    beginAtZero: true
                },
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Fungsi untuk menyimpan grafik sebagai gambar dengan nama tertentu
    function saveChartAsImage() {
        var chart = document.getElementById('totalRevenueChart');

        // Mendapatkan data URL dari grafik
        var imageData = chart.toDataURL('image/png');

        // Membuat elemen <a> untuk mengunduh gambar
        var a = document.createElement('a');
        a.href = imageData;
        a.download = 'total_revenue_chart.png'; // Nama file yang akan disimpan
        a.click();
    }
</script>
