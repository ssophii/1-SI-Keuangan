$(function () {
    $(".delete").click(function () {
        var username = $('#username').val();
        var element = $(this);
        var del_id = element.attr("id");
        var info = 'id=' + del_id;
            $.ajax({
                type: "POST",
                url: "ajax/ajax_delete_pengeluaran.php",
                data: info,
                success: function () {
                    location.reload(true)
                    // $(".tampil").load("ajax/tampilPemasukkanDel?filterSend=" + filter + '&username=' + username);
                }
            });
        // swal({
        //         title: 'Peringatan!',
        //         type: 'error',
        //         text: 'Yakin ingin menghapus data?',
        //         html: true,
        //         confirmButtonColor: '#d9534f',
        //         showCancelButton: true,
        //     },
        //     });
        return false;
    });
});