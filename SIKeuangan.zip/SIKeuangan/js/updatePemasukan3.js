$(document).ready(function () {

    // nampilin data
    $(document).on('click', 'a[data-role=update]', function () {
        var id_data = $(this).data('id');
        // var tanggal = 'test';
        var tanggal = $('#' + id_data).children('td[data-target=tanggal]').text();
        var keterangan = $('#' + id_data).children('td[data-target=keterangan]').text();
        var sumber = $('#' + id_data).children('td[data-target=sumber]').text();
        var jumlah = $('#' + id_data).children('td[data-target=jumlah]').text();

        $('#tanggal').val(tanggal);
        $('#keterangan').val(keterangan);
        $('#sumber').val(sumber);
        $('#jumlah').val(jumlah);
        $('#id_ya').val(id_data);
        $('#editModal').modal('toggle');
    });

    // buat event untuk get data dan update ke database
    $('#save').click(function () {
        var id_ya = $('#id_ya').val();
        var tanggal = $('#tanggal').val();
        var keterangan = $('#keterangan').val();
        var sumber = $('#sumber').val();
        var jumlah = $('#jumlah').val();

        $.ajax({
            url: 'ajax/ajax_update_pemasukan.php',
            method: 'post',
            data: {
                tanggal: tanggal,
                keterangan: keterangan,
                sumber: sumber,
                jumlah: jumlah,
                id: id_ya
            },
            success: function (response) {
                $('#' + id_ya).children('td[data-target=tanggal]').text(tanggal);
                $('#' + id_ya).children('td[data-target=keterangan]').text(keterangan);
                $('#' + id_ya).children('td[data-target=sumber]').text(sumber);
                $('#' + id_ya).children('td[data-target=jumlah]').text(jumlah);
                $('#editModal').modal('toggle');
                window.open(datapemasukan.php);
                // $(".tampil").load("ajax/tampilPemasukkan?filterSend=" + filter + '&username=' + username);
                location.reload();

            }
        });
    });
});